package com.zero.tianmao.pojo;

import java.sql.Timestamp;

public class Coupon {
    // 优惠券id
    String comptonId;

    // 优惠券类别
    String comptonType;

    // 优惠券数量
    Integer quantity;

    // 截止时间
    Timestamp deadline;
}
