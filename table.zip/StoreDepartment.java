package com.zero.tianmao.pojo;

// 各个店铺的部门
public class StoreDepartment {
    // 部门id
    String departmentId;

    // 店铺id
    String storeId;

    // 部门名称
    String departmentName;
}
