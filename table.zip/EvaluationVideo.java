package com.zero.tianmao.pojo;

import java.sql.Timestamp;

public class EvaluationVideo {
    // 视频id
    String evaluationVideoId;

    // 商品评价id
    String evaluationId;

    // 视频url
    String video;

    // 上传时间
    Timestamp uploadTime;
}
