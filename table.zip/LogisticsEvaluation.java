package com.zero.tianmao.pojo;

// 物流评价
public class LogisticsEvaluation {
    // 评价id
    String evaluationId;

    // 评价者的用户id
    String evaluatorId;

    // 快递公司标识符
    String courierCompany;

    // 星级
    Integer stars;
}
