package com.zero.tianmao.pojo;

public class StoreAuthority {
    // 店铺id
    String storeId;

    // 部门id
    String departmentId;

    // 职位id
    String jobTitleId;

    // 权限标识
    String authority;
}
