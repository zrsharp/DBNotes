package com.zero.tianmao.pojo;

// 店铺优惠券
public class StoreCoupon {
    // 优惠券id
    String couponId;

    // 店铺id
    String storeId;
}
