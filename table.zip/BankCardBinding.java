package com.zero.tianmao.pojo;

public class BankCardBinding {
    // 用户id
    String userId;

    // 银行
    String bank;

    // 银行卡类型
    String bankCardType;

    // 银行卡号
    String bankCardNumber;

}
