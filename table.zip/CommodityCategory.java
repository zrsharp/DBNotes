package com.zero.tianmao.pojo;

// 商品分类
public class CommodityCategory {
    // 分类id
    String categoryId;

    // 分类名称
    String categoryName;

    // 分类等级
    String categoryLevel;

    // 父级分类id
    String parentCategoryId;
}
