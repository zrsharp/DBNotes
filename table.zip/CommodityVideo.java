package com.zero.tianmao.pojo;

import java.sql.Timestamp;

// 商品视频
public class CommodityVideo {
    // 视频id
    String commodityVideoId;

    // 商品id
    String commodityId;

    // 视频url
    String video;

    // 上传时间
    Timestamp uploadTime;
}
