package com.zero.tianmao.pojo;

// 商品优惠券
public class CommodityCoupon {
    // 优惠券id
    String couponId;

    // 商品id
    String commodityId;
}
