package com.zero.tianmao.pojo;

public class JobTitle {
    // 职位id
    String jobTitleId;

    // 店铺id
    String storeId;

    // 部门id
    String departmentId;

    // 职位名称
    String JobTitleName;
}
