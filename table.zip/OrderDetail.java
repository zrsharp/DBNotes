package com.zero.tianmao.pojo;

public class OrderDetail {
    // 订单详情id
    String orderDetailId;

    // 对应的订单id
    String orderId;

    // 商品id
    String commodityId;

    // 商品数目
    String quantity;

    
}
