package com.zero.tianmao.pojo;

import java.sql.Timestamp;

// 购物车项
public class ShoppingCartItem {
    // 购物车id
    String shoppingCartId;

    // 商品id
    String commodityId;

    // 添加时间
    Timestamp addTime;
}
