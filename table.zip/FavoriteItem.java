package com.zero.tianmao.pojo;

import java.sql.Timestamp;

public class FavoriteItem {
    // 收藏夹id
    String favoriteId;

    // 商品id
    String commodityId;

    // 收藏时间
    Timestamp collectionTime;
}
