package com.zero.tianmao.pojo;

import java.sql.Timestamp;

public class Store {
    // 店铺id
    String storeId;

    // 卖家的用户id
    String sellerId;

    // 许可证号
    String license;

    // 店铺注册时间
    Timestamp registrationTime;
}
