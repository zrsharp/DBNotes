package com.zero.tianmao.pojo;

public class Order_ {
    String orderId;

    // 买家用户id
    String buyerId;

    // 卖家用户id
    String sellerId;

    // 订单流水号
    String serialNumber;

    // 订单状态标识
    String orderState;

    // 订单生成时间
    String orderGenerTime;
}
