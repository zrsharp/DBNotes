package com.zero.tianmao.pojo;

// 收藏夹
public class Favorite {
    // 收藏夹id
    String favoriteId;

    // 用户id
    String userId;

    // 收藏数量
    Integer quantity;
}
