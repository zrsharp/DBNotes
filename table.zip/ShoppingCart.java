package com.zero.tianmao.pojo;

// 购物车
public class ShoppingCart {
    // 购物车id
    String cartId;

    // 用户id
    String userId;

    // 购物车项目数量
    Integer quantity;
}
