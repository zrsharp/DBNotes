package com.zero.tianmao.pojo;

// 店铺服务态度评价
public class AttitudeEvaluation {
    // 评价id
    String evaluationId;

    // 评价者的用户id
    String evaluatorId;

    // 店铺id
    String storeId;

    // 星级
    Integer stars;
}
